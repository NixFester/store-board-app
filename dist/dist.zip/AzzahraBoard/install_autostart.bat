@echo off
setlocal

REM Location of this BAT file
set APPDIR=%~dp0

REM Startup folder
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

REM Create VBS helper to make shortcut
set VBS=%TEMP%\create_shortcut.vbs

echo Set oWS = WScript.CreateObject("WScript.Shell") > "%VBS%"
echo sLinkFile = "%STARTUP%\AzzahraBoard.lnk" >> "%VBS%"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%VBS%"
echo oLink.TargetPath = "%APPDIR%AzzahraBoard.exe" >> "%VBS%"
echo oLink.WorkingDirectory = "%APPDIR%" >> "%VBS%"
echo oLink.Save >> "%VBS%"

cscript //nologo "%VBS%"
del "%VBS%"

echo Startup shortcut created.
pause